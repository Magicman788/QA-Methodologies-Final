﻿namespace CanDriveTestProject
{
    [TestClass]
    public class TestCanDrive
    {
        public bool CanDrive(int age)
        { 
            const int drivingAge = 16;
            return age >= drivingAge;
        }

        [TestMethod]
        public void TestMethodIntMinValue()
        {
            Assert.AreEqual(false, CanDrive(int.MinValue));
        }

        [TestMethod]
        public void TestMethodIntMinValuePlusOne()
        {
            Assert.AreEqual(false, CanDrive(int.MinValue + 1));
        }

        [TestMethod]
        public void TestMethodMinusOne()
        {
            Assert.AreEqual(false, CanDrive(-1));
        }

        [TestMethod]
        public void TestMethodZero()
        {
            Assert.AreEqual(false, CanDrive(0));
        }

        [TestMethod]
        public void TestMethodOne()
        {
            Assert.AreEqual(false, CanDrive(1));
        }

        [TestMethod]
        public void TestMethodFifteen()
        {
            Assert.AreEqual(false, CanDrive(15));
        }

        [TestMethod]
        public void TestMethodSixteen()
        {
            Assert.AreEqual(true, CanDrive(16));
        }

        [TestMethod]
        public void TestMethodSeventeen()
        {
            Assert.AreEqual(true, CanDrive(17));
        }


        [TestMethod]
        public void TestMethodIntMaxValueMinusOne()
        {
            Assert.AreEqual(true, CanDrive(int.MaxValue - 1));
        }

        [TestMethod]
        public void TestMethodIntMaxValue()
        {
            Assert.AreEqual(true, CanDrive(int.MaxValue));
        }
    }
}
